import { Hono } from "hono";

export const imageRoutes = new Hono();

imageRoutes.get("/:npi", async (c) => {
  const file = Bun.file(`images/${c.req.param("npi")}.jpg`);
  if (!await file.exists()) return c.notFound();
  return new Response(file, { headers: { "Content-Type": "image/jpeg" } });
});
